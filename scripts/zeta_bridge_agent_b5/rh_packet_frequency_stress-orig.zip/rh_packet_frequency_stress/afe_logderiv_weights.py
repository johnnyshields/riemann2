#!/usr/bin/env python3
"""
afe_logderiv_weights.py

Corrected log-derivative / phase-consistent AFE weight helpers for the
packet-frequency determinant stress test.

Convention:
    A(s) = - zeta'(s) / zeta(s)
    C_k(s) = (-1)^k d_s^k A(s)

Main branch coefficient:
    Lambda(n) (log n)^k n^(-1/2-alpha) V^+(n/N^+)
    phase exp(-i m log n)

Reflected dual branch coefficient:
    sigma_k Lambda(n) (log n)^k n^(-1/2+alpha) V^-(n/N^-)
    phase exp(+i m log n)
    sigma_k = (-1)^(k+1)

No multiplicative chi(s) appears in these reflected log-derivative dual
coefficients. The additive gamma/background term must be handled separately.

Important defaults for Agent 5's current script convention:
    k_Z = 0     # zero/incidence row z_n = Lambda(n) n^-1/2-alpha
    k_q = 3     # current Wronskian surrogate source row

Literal q''_can source-row tests should use:
    k_q = 2

Operator node convention:
    plus branch op-node:  +log n
    minus branch op-node: -log n  (signed real-frequency convention)
The folded conductor node log(m/(2*pi*n)) is diagnostic only and should not
be used as the Wronskian differential/operator node unless a folded operator
has explicitly been defined.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Callable, Iterable, Optional, Tuple

import numpy as np


def sigma_k(k: int) -> int:
    """sigma_k = (-1)^(k+1)."""
    return -1 if (k % 2 == 0) else 1


def lambda_prime_only(n: int) -> float:
    """Von Mangoldt for prime-only runs; assumes n is prime."""
    return math.log(int(n))


def von_mangoldt_trial(n: int) -> float:
    """Small fallback von Mangoldt via trial division. Fine for toy runs."""
    n = int(n)
    if n < 2:
        return 0.0
    # check prime powers
    p = 2
    temp = n
    factors = []
    d = 2
    while d * d <= temp:
        if temp % d == 0:
            count = 0
            while temp % d == 0:
                temp //= d
                count += 1
            factors.append((d, count))
        d += 1 if d == 2 else 2
    if temp > 1:
        factors.append((temp, 1))
    if len(factors) == 1:
        return math.log(factors[0][0])
    return 0.0


def smooth_plateau(y: float) -> float:
    return 1.0


def smooth_bump(y: float) -> float:
    """C-infinity compact bump on [0,1), normalized to V(0)=1."""
    y = float(y)
    if y < 0.0 or y >= 1.0:
        return 0.0
    return math.exp(-1.0 / (1.0 - y * y)) / math.exp(-1.0)


def get_smoothing(name: str) -> Callable[[float], float]:
    if name in ("plateau", "one", "none"):
        return smooth_plateau
    if name == "bump":
        return smooth_bump
    raise ValueError(f"unknown smoothing: {name!r}")


@dataclass
class BranchWeights:
    coeffs: np.ndarray          # coefficient symbols, without phase
    phases: np.ndarray          # exp(∓ i m log n)
    op_nodes: np.ndarray        # operator nodes, used for basis construction
    folded_nodes: np.ndarray    # diagnostic only
    weights_for_qr: np.ndarray  # abs(coeffs)^2
    logs: np.ndarray            # log n
    n_values: np.ndarray


def build_logderiv_weights(
    n_values: Iterable[int | float],
    m: float,
    alpha: float,
    branch: str,
    k: int,
    N: Optional[float] = None,
    smoothing: str | Callable[[float], float] = "plateau",
    lambda_func: Callable[[int], float] = lambda_prime_only,
    signed_operator_nodes: bool = True,
) -> BranchWeights:
    """
    Build corrected reflected log-derivative AFE branch weights.

    Args:
        branch: 'plus' or 'minus'.
        k: C_k index. Agent 5 current defaults: k_Z=0, k_q=3.
        N: smoothing conductor. If None, V=1 regardless of smoothing.
        smoothing: 'plateau', 'bump', or callable V(y).
        signed_operator_nodes: if True, minus op-node is -log n.

    Returns:
        BranchWeights with coeffs, phases, operator nodes, folded nodes.
    """
    if callable(smoothing):
        Vfun = smoothing
    else:
        Vfun = get_smoothing(smoothing)

    coeffs = []
    phases = []
    op_nodes = []
    folded_nodes = []
    logs = []
    ns = []

    for n0 in n_values:
        n = int(n0)
        L = math.log(n)
        Lam = lambda_func(n)
        V = 1.0 if N is None else Vfun(n / N)

        if branch == "plus":
            coeff = Lam * (L ** k) * (n ** (-0.5 - alpha)) * V
            phase = np.exp(-1j * m * L)
            op_node = +L if signed_operator_nodes else L
            folded_node = L
        elif branch == "minus":
            coeff = sigma_k(k) * Lam * (L ** k) * (n ** (-0.5 + alpha)) * V
            phase = np.exp(+1j * m * L)
            op_node = -L if signed_operator_nodes else L
            folded_node = math.log(m / (2.0 * math.pi * n)) if m > 0 else float("nan")
        else:
            raise ValueError("branch must be 'plus' or 'minus'")

        coeffs.append(complex(coeff))
        phases.append(complex(phase))
        op_nodes.append(float(op_node))
        folded_nodes.append(float(folded_node))
        logs.append(float(L))
        ns.append(int(n))

    coeffs_a = np.asarray(coeffs, dtype=np.complex128)
    return BranchWeights(
        coeffs=coeffs_a,
        phases=np.asarray(phases, dtype=np.complex128),
        op_nodes=np.asarray(op_nodes, dtype=float),
        folded_nodes=np.asarray(folded_nodes, dtype=float),
        weights_for_qr=np.abs(coeffs_a) ** 2,
        logs=np.asarray(logs, dtype=float),
        n_values=np.asarray(ns, dtype=np.int64),
    )


def conductor_sqrt_m(m: float) -> float:
    if m <= 0:
        raise ValueError("m must be positive for sqrt(m/(2*pi)) conductor")
    return math.sqrt(m / (2.0 * math.pi))


def conductor_cover_block(n_values: Iterable[int | float], y_at_max: float = 0.5) -> float:
    """Choose N so max(n)/N = y_at_max, keeping a block inside a bump plateau-ish region."""
    vals = [float(n) for n in n_values]
    if not vals:
        raise ValueError("empty n_values")
    return max(vals) / y_at_max
