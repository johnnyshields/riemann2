#!/usr/bin/env python3
"""
packet_frequency_stress.py

Executable packet-frequency determinant stress-test harness for the ordinary
Wronskian route.

This harness is for numerical/surrogate testing. It is not a proof-level AFE.
It implements the corrected log-derivative reflected dual convention:
    k_Z = 0 for the current zero/incidence row
    k_q = 3 for the current script source-row surrogate
    k_q = 2 for literal q''_can source-row experiments
    dual operator node != folded conductor node

Stages:
    main_orbit          : plus branch only, one-parameter orbit
    relaxed             : plus branch only, independent phase negative control
    b2                  : plus branch plus canonical B2 toy/background injection
    formal_dual         : plus + reflected minus branch with plateau smoothing
    actual_like_dual    : plus + reflected minus branch with selected smoothing/conductor policy
    e2                  : row perturbation test on strongest actual-like candidates

Outputs one CSV row per candidate.
"""

from __future__ import annotations

import argparse
import csv
import dataclasses
import json
import math
import os
import random
import time
import uuid
from dataclasses import dataclass, asdict
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

try:
    import scipy.optimize as opt
except Exception:
    opt = None

try:
    import sympy as sp
except Exception:
    sp = None

try:
    import yaml  # optional
except Exception:
    yaml = None

from b2_canonical import B2_fast_3term, B2_exact
from afe_logderiv_weights import (
    BranchWeights,
    build_logderiv_weights,
    conductor_cover_block,
    conductor_sqrt_m,
    lambda_prime_only,
)

EPS = 1e-300


# ============================================================
# Dataclasses
# ============================================================

@dataclass
class PrimeBlock:
    R: int
    Q: float
    c: float
    lam: float
    u_min: float
    u_max: float
    u0: float
    L: float
    primes: np.ndarray
    logs: np.ndarray

    @property
    def lambda_u0(self) -> float:
        return self.lam * self.u0

    @property
    def lambda_L(self) -> float:
        return self.lam * self.L


@dataclass
class TermSet:
    z_coeffs: np.ndarray
    c_coeffs: np.ndarray
    z_phases: np.ndarray
    c_phases: np.ndarray
    op_nodes_z: np.ndarray
    op_nodes_c: np.ndarray
    folded_nodes_z: np.ndarray
    folded_nodes_c: np.ndarray
    branch_labels_z: List[str]
    branch_labels_c: List[str]
    logs_z: np.ndarray
    logs_c: np.ndarray


@dataclass
class Basis:
    Phi_z: np.ndarray
    Phi_c: np.ndarray
    x_z: np.ndarray
    x_c: np.ndarray
    x_center: float
    x_halfwidth: float
    kappa_basis: float
    gram_error: float


@dataclass
class Diagnostics:
    eta_Z: float
    log_eta_Z: float
    eta_W: float
    log_eta_W: float
    eta_sv: float
    sigma_min: float
    sigma_max: float
    row_norm_min: float
    row_norm_max: float
    rho_rank_2: float
    rho_rank_inf: float
    kappa_basis: float
    gram_error: float
    objective_value: float


@dataclass
class CandidateRow:
    run_id: str
    timestamp: str
    stage: str
    R: int
    Q: float
    lambda_: float
    c: float
    u_min: float
    u_max: float
    u0: float
    L: float
    num_primes: int
    alpha: float
    m: float
    lambda_u0: float
    lambda_L: float
    op_node_min: float
    op_node_max: float
    diam_x: float
    eta_Z: float
    log_eta_Z: float
    eta_W: float
    log_eta_W: float
    eta_sv: float
    rho_rank_2: float
    rho_rank_inf: float
    kappa_basis: float
    gram_error: float
    eta_E2_det: float
    row_norm_min: float
    row_norm_max: float
    sigma_min: float
    sigma_max: float
    objective_value: float
    collapse_class: str
    notes: str
    k_Z: int
    k_q: int
    source_mode: str
    smoothing: str
    conductor_policy: str
    dual_type: str = ""
    dual_node_convention: str = "operator_signed"
    num_dual_terms: int = 0
    E2_model: str = ""
    E2_trials: int = 0
    eta_W_median_perturbed: float = float("nan")
    eta_W_worst_perturbed: float = float("nan")
    eta_W_best_perturbed: float = float("nan")
    survives_E2: bool = False


CSV_FIELDS = list(CandidateRow.__dataclass_fields__.keys())


# ============================================================
# Config helpers
# ============================================================

def load_config(path: Optional[str]) -> Dict[str, Any]:
    if not path:
        return {}
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    if path.endswith((".yaml", ".yml")):
        if yaml is None:
            raise RuntimeError("PyYAML not installed; use JSON config or install pyyaml")
        return yaml.safe_load(text) or {}
    return json.loads(text)


def cfg_get(cfg: Dict[str, Any], key: str, default: Any) -> Any:
    return cfg.get(key, default)


# ============================================================
# Prime/block helpers
# ============================================================

def primes_in_interval(lo: int, hi: int, max_count: Optional[int] = None) -> List[int]:
    lo = max(2, int(lo))
    hi = int(hi)
    if lo > hi:
        return []
    if sp is not None:
        ps = list(sp.primerange(lo, hi + 1))
        if max_count and len(ps) > max_count:
            idx = np.linspace(0, len(ps) - 1, max_count).astype(int)
            ps = [ps[i] for i in idx]
        return ps
    # fallback simple trial division; intended only for small toy intervals
    def is_prime(n: int) -> bool:
        if n < 2:
            return False
        if n % 2 == 0:
            return n == 2
        d = 3
        while d * d <= n:
            if n % d == 0:
                return False
            d += 2
        return True
    out = []
    for n in range(lo, hi + 1):
        if is_prime(n):
            out.append(n)
            if max_count and len(out) >= max_count:
                break
    return out


def choose_Q_for_R(R: int, mode: str) -> float:
    if mode == "toy":
        return float(20 + 2 * R)
    if mode == "larger_toy":
        return float(40 + 3 * R)
    if mode.startswith("fixed:"):
        return float(mode.split(":", 1)[1])
    raise ValueError(f"unknown Q mode: {mode}")


def build_prime_block(R: int, Q: float, c: float, max_primes: Optional[int]) -> PrimeBlock:
    lam = 1.0 / Q
    u_min = c * Q
    u_max = c * Q + Q / R
    u0 = 0.5 * (u_min + u_max)
    L = u_max - u_min
    p_min = int(math.ceil(math.exp(u_min)))
    p_max = int(math.floor(math.exp(u_max)))
    ps = primes_in_interval(p_min, p_max, max_count=max_primes)
    arr = np.asarray(ps, dtype=np.float64)
    logs = np.log(arr) if len(arr) else np.asarray([], dtype=float)
    return PrimeBlock(R=R, Q=Q, c=c, lam=lam, u_min=u_min, u_max=u_max, u0=u0, L=L, primes=arr, logs=logs)


# ============================================================
# Basis and matrix helpers
# ============================================================

def cheb_vander(x: np.ndarray, degree: int) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    A = np.zeros((len(x), degree + 1), dtype=float)
    if degree >= 0:
        A[:, 0] = 1.0
    if degree >= 1:
        A[:, 1] = x
    for j in range(2, degree + 1):
        A[:, j] = 2 * x * A[:, j - 1] - A[:, j - 2]
    return A


def normalize_nodes(op_nodes: np.ndarray) -> Tuple[np.ndarray, float, float]:
    mn = float(np.min(op_nodes))
    mx = float(np.max(op_nodes))
    center = 0.5 * (mn + mx)
    half = 0.5 * (mx - mn)
    if half <= 0:
        half = 1.0
    return (op_nodes - center) / half, center, half


def build_basis(op_nodes_z: np.ndarray, op_nodes_c: np.ndarray, weights_c: np.ndarray, degree: int) -> Basis:
    # Build basis on source/operator nodes, then evaluate also on z nodes.
    x_c, center, half = normalize_nodes(op_nodes_c)
    x_z = (op_nodes_z - center) / half
    A_c = cheb_vander(x_c, degree)
    Aw = np.sqrt(weights_c)[:, None] * A_c
    Qmat, Rmat = np.linalg.qr(Aw, mode="reduced")
    Phi_c = Qmat / np.sqrt(weights_c)[:, None]
    invR = np.linalg.inv(Rmat)
    A_z = cheb_vander(x_z, degree)
    Phi_z = A_z @ invR
    Gram = Phi_c.conj().T @ (weights_c[:, None] * Phi_c)
    gram_error = float(np.linalg.norm(Gram - np.eye(degree + 1), ord=2))
    kappa = float(np.linalg.cond(Rmat))
    return Basis(Phi_z=Phi_z, Phi_c=Phi_c, x_z=x_z, x_c=x_c, x_center=center, x_halfwidth=half, kappa_basis=kappa, gram_error=gram_error)


def build_M(terms: TermSet, basis: Basis, R: int, b2_value: Optional[float] = None) -> np.ndarray:
    d = R + 2
    M = np.zeros((d, d), dtype=np.complex128)
    # Z row
    for ell in range(d):
        M[0, ell] = np.sum(terms.z_coeffs * basis.Phi_z[:, ell] * terms.z_phases)
    # source rows
    for j in range(R + 1):
        for ell in range(d):
            M[j + 1, ell] = np.sum(terms.c_coeffs * basis.Phi_c[:, j] * basis.Phi_c[:, ell] * terms.c_phases)
    # Toy/literal B2 injection: exact canonical value but simplified projection.
    # For proof-level use, replace by phi_l(D) phi_j(D) B2 with polynomial coefficients.
    if b2_value is not None:
        for row in range(1, d):
            M[row, 0] += b2_value
    return M


# ============================================================
# Diagnostics
# ============================================================

def eta_Z_direct(terms: TermSet) -> Tuple[float, float]:
    Z = np.sum(terms.z_coeffs * terms.z_phases)
    denom = float(np.linalg.norm(terms.z_coeffs))
    eta = float(abs(Z) / max(denom, EPS))
    return eta, math.log(max(eta, EPS))


def det_diagnostics(M: np.ndarray) -> Dict[str, float]:
    s = np.linalg.svd(M, compute_uv=False)
    rows = np.linalg.norm(M, axis=1)
    log_eta_W = float(np.sum(np.log(np.maximum(s, EPS))) - np.sum(np.log(np.maximum(rows, EPS))))
    return {
        "eta_W": float(math.exp(max(log_eta_W, math.log(EPS)))),
        "log_eta_W": log_eta_W,
        "eta_sv": float(s[-1] / max(s[0], EPS)),
        "sigma_min": float(s[-1]),
        "sigma_max": float(s[0]),
        "row_norm_min": float(np.min(rows)),
        "row_norm_max": float(np.max(rows)),
    }


def symbol_rank_residual(x: np.ndarray, r: np.ndarray, weights: np.ndarray, R: int) -> Tuple[float, float]:
    V = cheb_vander(x, R)
    Vw = np.sqrt(weights)[:, None] * V
    rw = np.sqrt(weights) * r
    coeff, *_ = np.linalg.lstsq(Vw, rw, rcond=None)
    fit = V @ coeff
    resid = r - fit
    return float(np.sqrt(np.sum(weights * np.abs(resid) ** 2))), float(np.max(np.abs(resid)))


# ============================================================
# Term construction
# ============================================================

def get_N(policy: str, n_values: np.ndarray, m: float) -> Optional[float]:
    if policy == "plateau" or policy == "none":
        return None
    if policy == "cover_block":
        return conductor_cover_block(n_values, y_at_max=0.5)
    if policy == "sqrt_m":
        return conductor_sqrt_m(m)
    raise ValueError(f"unknown conductor policy: {policy}")


def build_terms(
    block: PrimeBlock,
    m: float,
    alpha: float,
    stage: str,
    k_Z: int,
    k_q: int,
    smoothing: str,
    conductor_policy: str,
) -> TermSet:
    n_values = block.primes.astype(int)
    N_Z = get_N(conductor_policy, n_values, m)
    N_q = get_N(conductor_policy, n_values, m)

    zp = build_logderiv_weights(n_values, m=m, alpha=alpha, branch="plus", k=k_Z, N=N_Z, smoothing=smoothing)
    cp = build_logderiv_weights(n_values, m=m, alpha=0.0, branch="plus", k=k_q, N=N_q, smoothing=smoothing)

    z_coeffs = [zp.coeffs]
    z_phases = [zp.phases]
    z_nodes = [zp.op_nodes]
    z_folded = [zp.folded_nodes]
    z_logs = [zp.logs]
    z_labels = ["plus"] * len(zp.coeffs)

    c_coeffs = [cp.coeffs]
    c_phases = [cp.phases]
    c_nodes = [cp.op_nodes]
    c_folded = [cp.folded_nodes]
    c_logs = [cp.logs]
    c_labels = ["plus"] * len(cp.coeffs)

    if stage in {"formal_dual", "actual_like_dual", "e2"}:
        # Corrected reflected log-derivative dual. For now formal and actual_like
        # differ by smoothing/conductor config, not by chi-multiplicative weights.
        zm = build_logderiv_weights(n_values, m=m, alpha=alpha, branch="minus", k=k_Z, N=N_Z, smoothing=smoothing)
        cm = build_logderiv_weights(n_values, m=m, alpha=0.0, branch="minus", k=k_q, N=N_q, smoothing=smoothing)
        z_coeffs.append(zm.coeffs); z_phases.append(zm.phases); z_nodes.append(zm.op_nodes); z_folded.append(zm.folded_nodes); z_logs.append(zm.logs)
        c_coeffs.append(cm.coeffs); c_phases.append(cm.phases); c_nodes.append(cm.op_nodes); c_folded.append(cm.folded_nodes); c_logs.append(cm.logs)
        z_labels += ["minus"] * len(zm.coeffs)
        c_labels += ["minus"] * len(cm.coeffs)

    return TermSet(
        z_coeffs=np.concatenate(z_coeffs),
        c_coeffs=np.concatenate(c_coeffs),
        z_phases=np.concatenate(z_phases),
        c_phases=np.concatenate(c_phases),
        op_nodes_z=np.concatenate(z_nodes),
        op_nodes_c=np.concatenate(c_nodes),
        folded_nodes_z=np.concatenate(z_folded),
        folded_nodes_c=np.concatenate(c_folded),
        branch_labels_z=z_labels,
        branch_labels_c=c_labels,
        logs_z=np.concatenate(z_logs),
        logs_c=np.concatenate(c_logs),
    )


def terms_with_relaxed_phases(terms: TermSet, rng: np.random.Generator) -> TermSet:
    z_phase = np.exp(-1j * rng.uniform(0, 2 * np.pi, size=len(terms.z_coeffs)))
    c_phase = np.exp(-1j * rng.uniform(0, 2 * np.pi, size=len(terms.c_coeffs)))
    return dataclasses.replace(terms, z_phases=z_phase, c_phases=c_phase)


# ============================================================
# Evaluation and search
# ============================================================

def evaluate(block: PrimeBlock, terms: TermSet, R: int, stage: str, include_b2: bool) -> Tuple[Diagnostics, np.ndarray, Basis]:
    weights_c = np.maximum(np.abs(terms.c_coeffs) ** 2, EPS)
    basis = build_basis(terms.op_nodes_z, terms.op_nodes_c, weights_c, degree=R + 1)
    b2 = B2_fast_3term(block.u0) if include_b2 else None
    M = build_M(terms, basis, R, b2_value=b2)
    eta_z, log_eta_z = eta_Z_direct(terms)
    dd = det_diagnostics(M)
    # rank residual: ratio z/c only branch-matched approximately; use z nodes with z/c norm over shared first len if shapes match.
    # Better for two-branch: fit the z/source ratio where possible by using interpolated simple ratio on z terms.
    min_len = min(len(terms.z_coeffs), len(terms.c_coeffs))
    r = terms.z_coeffs[:min_len] / np.maximum(terms.c_coeffs[:min_len], EPS)
    w = np.maximum(np.abs(terms.c_coeffs[:min_len]) ** 2, EPS)
    x = basis.x_c[:min_len]
    rho2, rhoinf = symbol_rank_residual(x, r, w, R)
    diag = Diagnostics(
        eta_Z=eta_z,
        log_eta_Z=log_eta_z,
        eta_W=dd["eta_W"],
        log_eta_W=dd["log_eta_W"],
        eta_sv=dd["eta_sv"],
        sigma_min=dd["sigma_min"],
        sigma_max=dd["sigma_max"],
        row_norm_min=dd["row_norm_min"],
        row_norm_max=dd["row_norm_max"],
        rho_rank_2=rho2,
        rho_rank_inf=rhoinf,
        kappa_basis=basis.kappa_basis,
        gram_error=basis.gram_error,
        objective_value=eta_z ** 2 + dd["eta_W"] ** 2,
    )
    return diag, M, basis


def scan_orbit(block: PrimeBlock, cfg: Dict[str, Any], stage: str, alpha: float, grid_size: int) -> Tuple[float, Diagnostics, np.ndarray, Basis]:
    m_min = float(cfg.get("m_min", 0.0))
    m_max = float(cfg.get("m_max_factor", 100.0)) * block.Q
    best = None
    best_m = m_min
    for m in np.linspace(m_min, m_max, grid_size):
        terms = build_terms(
            block, m=m, alpha=alpha, stage=stage,
            k_Z=int(cfg.get("k_Z", 0)), k_q=int(cfg.get("k_q", 3)),
            smoothing=str(cfg.get("smoothing", "plateau")),
            conductor_policy=str(cfg.get("conductor_policy", "plateau")),
        )
        diag, M, basis = evaluate(block, terms, block.R, stage, include_b2=(stage == "b2" or cfg.get("include_b2", False)))
        if best is None or diag.objective_value < best[0].objective_value:
            best = (diag, M, basis)
            best_m = float(m)
    assert best is not None
    return best_m, best[0], best[1], best[2]


def relaxed_search(block: PrimeBlock, cfg: Dict[str, Any], alpha: float, restarts: int) -> Tuple[float, Diagnostics, np.ndarray, Basis]:
    rng = np.random.default_rng(int(cfg.get("seed", 12345)))
    best = None
    best_m = float("nan")
    m0 = float(cfg.get("relaxed_m", max(1.0, block.Q)))
    base_terms = build_terms(block, m=m0, alpha=alpha, stage="main", k_Z=int(cfg.get("k_Z", 0)), k_q=int(cfg.get("k_q", 3)), smoothing=str(cfg.get("smoothing", "plateau")), conductor_policy=str(cfg.get("conductor_policy", "plateau")))
    for _ in range(restarts):
        terms = terms_with_relaxed_phases(base_terms, rng)
        diag, M, basis = evaluate(block, terms, block.R, "relaxed", include_b2=False)
        if best is None or diag.objective_value < best[0].objective_value:
            best = (diag, M, basis)
    assert best is not None
    return best_m, best[0], best[1], best[2]


def E2_perturbation(M: np.ndarray, trials: int, scale: float, seed: int = 123) -> Dict[str, Any]:
    rng = np.random.default_rng(seed)
    row_norms = np.linalg.norm(M, axis=1)
    eta_rows = scale * np.maximum(row_norms, EPS)
    vals = []
    for _ in range(trials):
        dM = np.zeros_like(M)
        for j, eta in enumerate(eta_rows):
            v = rng.normal(size=M.shape[1]) + 1j * rng.normal(size=M.shape[1])
            v /= max(np.linalg.norm(v), EPS)
            dM[j, :] = eta * v
        vals.append(det_diagnostics(M + dM)["eta_W"])
    return {
        "E2_trials": trials,
        "eta_W_median_perturbed": float(np.median(vals)),
        "eta_W_worst_perturbed": float(np.max(vals)),
        "eta_W_best_perturbed": float(np.min(vals)),
        "survives_E2": bool(np.median(vals) <= 10.0 * det_diagnostics(M)["eta_W"]),
    }


# ============================================================
# Classification/logging
# ============================================================

def classify(stage: str, Q: float, diag: Diagnostics, survives_E2: bool, cfg: Dict[str, Any]) -> str:
    CZ = float(cfg.get("C_Z", 6.0)); CW = float(cfg.get("C_W", 6.0)); CR = float(cfg.get("C_rank", 4.0)); CK = float(cfg.get("C_kappa", 4.0))
    healthy = diag.rho_rank_2 >= Q ** (-CR) and diag.kappa_basis <= Q ** CK
    collapsed = diag.eta_Z <= Q ** (-CZ) and diag.eta_W <= Q ** (-CW)
    if not healthy:
        return "degenerate"
    if stage == "relaxed" and collapsed:
        return "relaxed_only_possible"
    if stage in {"main_orbit", "b2"} and collapsed:
        return "yellow_orbit_collapse"
    if stage in {"formal_dual", "actual_like_dual"} and collapsed:
        return "red_candidate_pre_E2"
    if stage == "e2" and collapsed and survives_E2:
        return "red_collapse"
    return "no_collapse"


def make_row(run_id: str, block: PrimeBlock, stage: str, alpha: float, m: float, diag: Diagnostics, cfg: Dict[str, Any], notes: str, e2: Optional[Dict[str, Any]] = None) -> CandidateRow:
    e2 = e2 or {}
    survives = bool(e2.get("survives_E2", False))
    op_min = float("nan"); op_max = float("nan"); diam_x = 2.0
    return CandidateRow(
        run_id=run_id, timestamp=time.strftime("%Y-%m-%d %H:%M:%S"), stage=stage,
        R=block.R, Q=block.Q, lambda_=block.lam, c=block.c,
        u_min=block.u_min, u_max=block.u_max, u0=block.u0, L=block.L,
        num_primes=len(block.primes), alpha=alpha, m=m,
        lambda_u0=block.lambda_u0, lambda_L=block.lambda_L,
        op_node_min=op_min, op_node_max=op_max, diam_x=diam_x,
        eta_Z=diag.eta_Z, log_eta_Z=diag.log_eta_Z, eta_W=diag.eta_W, log_eta_W=diag.log_eta_W,
        eta_sv=diag.eta_sv, rho_rank_2=diag.rho_rank_2, rho_rank_inf=diag.rho_rank_inf,
        kappa_basis=diag.kappa_basis, gram_error=diag.gram_error, eta_E2_det=float("nan"),
        row_norm_min=diag.row_norm_min, row_norm_max=diag.row_norm_max,
        sigma_min=diag.sigma_min, sigma_max=diag.sigma_max,
        objective_value=diag.objective_value,
        collapse_class=classify(stage, block.Q, diag, survives, cfg), notes=notes,
        k_Z=int(cfg.get("k_Z", 0)), k_q=int(cfg.get("k_q", 3)), source_mode=str(cfg.get("source_mode", "script_kq3")),
        smoothing=str(cfg.get("smoothing", "plateau")), conductor_policy=str(cfg.get("conductor_policy", "plateau")),
        dual_type=("reflected_logderiv" if stage in {"formal_dual", "actual_like_dual", "e2"} else ""),
        E2_model=e2.get("E2_model", ""), E2_trials=int(e2.get("E2_trials", 0)),
        eta_W_median_perturbed=float(e2.get("eta_W_median_perturbed", float("nan"))),
        eta_W_worst_perturbed=float(e2.get("eta_W_worst_perturbed", float("nan"))),
        eta_W_best_perturbed=float(e2.get("eta_W_best_perturbed", float("nan"))),
        survives_E2=survives,
    )


def write_rows(path: str, rows: List[CandidateRow]) -> None:
    exists = os.path.exists(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(CandidateRow.__dataclass_fields__.keys()))
        if not exists:
            writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


# ============================================================
# Main
# ============================================================

def alpha_grid(R: int, L: float) -> List[float]:
    vals = [0.0, R ** -2, -R ** -2, R ** -1, -R ** -1, 1.0, -1.0, 2.0, -2.0]
    return [float(v / max(L, EPS)) for v in vals]


def run(cfg: Dict[str, Any]) -> None:
    run_id = str(uuid.uuid4())[:8]
    output = str(cfg.get("output", "results/packet_frequency_results.csv"))
    os.makedirs(os.path.dirname(output) or ".", exist_ok=True)
    rows: List[CandidateRow] = []
    R_values = [int(x) for x in cfg.get("R_values", [4, 6, 8, 10, 12])]
    c_values = [float(x) for x in cfg.get("c_values", [0.1, 0.2, 0.3, 0.4])]
    stages = list(cfg.get("stages", ["relaxed", "main_orbit"]))

    for R in R_values:
        Q = choose_Q_for_R(R, str(cfg.get("Q_mode", "toy")))
        for c in c_values:
            block = build_prime_block(R=R, Q=Q, c=c, max_primes=cfg.get("max_primes", 5000))
            if len(block.primes) < int(cfg.get("min_primes_factor", 4)) * (R + 2):
                print(f"skip R={R} c={c}: too few primes ({len(block.primes)})")
                continue
            for alpha in alpha_grid(R, block.L):
                if "relaxed" in stages:
                    m, diag, M, basis = relaxed_search(block, cfg, alpha, int(cfg.get("relaxed_restarts", 64)))
                    rows.append(make_row(run_id, block, "relaxed", alpha, m, diag, cfg, "phase-relaxed negative control"))
                for stage in ["main_orbit", "b2", "formal_dual", "actual_like_dual"]:
                    if stage not in stages:
                        continue
                    internal_stage = "main" if stage in {"main_orbit", "b2"} else stage
                    m, diag, M, basis = scan_orbit(block, cfg, internal_stage if stage not in {"b2"} else "main", alpha, int(cfg.get("m_grid", 1000)))
                    # If B2 requested, rescan with b2 include via stage handled by scan_orbit only in build/evaluate if stage==b2.
                    if stage == "b2":
                        m, diag, M, basis = scan_orbit(block, {**cfg, "include_b2": True}, "b2", alpha, int(cfg.get("m_grid", 1000)))
                    rows.append(make_row(run_id, block, stage, alpha, m, diag, cfg, stage))
                    if stage == "actual_like_dual" and "e2" in stages:
                        e2 = E2_perturbation(M, int(cfg.get("E2_trials", 200)), float(cfg.get("E2_scale", 1e-8)), seed=int(cfg.get("seed", 123)))
                        rows.append(make_row(run_id, block, "e2", alpha, m, diag, cfg, "E2 row perturbation", e2={**e2, "E2_model": "row_perturbation"}))
                if len(rows) >= int(cfg.get("flush_every", 50)):
                    write_rows(output, rows); rows.clear()
    if rows:
        write_rows(output, rows)
    print(f"wrote {output}")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default=None, help="JSON/YAML config file")
    p.add_argument("--output", default=None)
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    cfg = load_config(args.config)
    if args.output:
        cfg["output"] = args.output
    run(cfg)
