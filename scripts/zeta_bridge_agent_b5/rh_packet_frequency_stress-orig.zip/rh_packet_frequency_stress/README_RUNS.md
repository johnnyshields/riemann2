# RH packet-frequency determinant stress-test scripts

## Files

- `b2_canonical.py` — frozen canonical gamma/background curvature term.
- `afe_logderiv_weights.py` — corrected reflected log-derivative AFE branch weights.
- `packet_frequency_stress.py` — determinant stress-test harness.
- `configs/*.json` — staged run configurations.

## Mandatory conventions locked in

Current Agent 5 script convention:

- `k_Z = 0` for the zero/incidence row.
- `k_q = 3` for the current Wronskian/source surrogate.
- Use `k_q = 2` for literal `q''_can` source-row experiments.
- Reflected dual coefficients use `sigma_k = (-1)^(k+1)`.
- No multiplicative `chi(s)` appears in reflected log-derivative dual coefficients.
- Dual Wronskian operator node is the signed differential node (`-log n` under the real signed-frequency convention), not the folded conductor diagnostic node.
- `B2` is canonical and included by default where the real phase-curvature background is being tested; B2-only rows are diagnostics only.

## Install

```bash
python -m pip install -r requirements.txt
```

## Run sequence

Run from this directory:

```bash
python packet_frequency_stress.py --config configs/01_main_relaxed_orbit.json
python packet_frequency_stress.py --config configs/02_plus_B2.json
python packet_frequency_stress.py --config configs/03_reflected_dual.json
python packet_frequency_stress.py --config configs/04_actual_like_dual_cover_block.json
python packet_frequency_stress.py --config configs/05_literal_q2_dual_cover_block.json
python packet_frequency_stress.py --config configs/06_full_larger_toy.json
```

## Stop-rule interpretation

- Relaxed-only collapse: harmless negative control.
- One-parameter main-only collapse: Yellow; inspect dual.
- Collapse killed by reflected dual: useful; main/dual arithmetic may be the proof lever.
- Actual-like reflected dual collapse surviving E2 and persisting with increasing R: Red; pause Wronskian route.

## Caveats

This is a stress-test harness, not a proof-level AFE. Proof-level canonicalization still requires exact smoothed Mellin AFE weights, derivative terms of `V^±` when conductors depend on `m`, `E2` error theorem, and projection conventions for complex `C_k` rows versus real phase-curvature rows.
